<footer>
	<div class="jagarta-footer">
		<div class="container">
			<div class="row height-200 ">
				<div class="col-md-6 col-lg-4 col-xl-3 margin-top-5p">
					<img src="<?php echo e(asset('img/logo.png')); ?>">
				</div>
				<div class="col-md-6 col-lg-4 col-xl-3 p-white margin-top-5p">
					<p>Indonesia Stock Exchange Tower I, 26th Floor <br>
						Jl. Jendral Sudirman Kav 52-53 Jakarta Selatan <br>
						(021) 5155 077</p>
				</div>
				<div class="col-md-6 col-lg-4 col-xl-3 p-white margin-top-5p">
					<p>info@@jagartha-advisors.com <br>
					www.jagartha.com</p>
				</div>
			</div>
		</div>
	</div>
</footer>
<?php /**PATH /Users/macbook-air/Desktop/kerja/Jagarta/Jagarta_web/resources/views/frontend/includes/footer.blade.php ENDPATH**/ ?>