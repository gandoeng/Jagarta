<!doctype html>
<html lang="<?php echo e(htmlLang()); ?>" <?php if (\Illuminate\Support\Facades\Blade::check('langrtl')): ?> dir="rtl" <?php endif; ?>>
<head>
    <meta charset="utf-8">
    <!--<meta name="viewport" content="width=device-width, initial-scale=1">-->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Jagartha | <?php echo $__env->yieldContent('title'); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description', appName()); ?>">
    <meta name="author" content="<?php echo $__env->yieldContent('meta_author', 'Anthony Rappa'); ?>">
    <?php echo $__env->yieldContent('meta'); ?>

    <?php echo $__env->yieldPushContent('before-styles'); ?>
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <?php echo toastr_css(); ?>
    <link href="<?php echo e(mix('css/frontend.css')); ?>" rel="stylesheet">
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php echo $__env->yieldPushContent('after-styles'); ?>
</head>
<body>

        <?php echo $__env->make('frontend.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('includes.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('frontend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldPushContent('before-scripts'); ?>
    <script src="<?php echo e(mix('js/manifest.js')); ?>"></script>
    <script src="<?php echo e(mix('js/vendor.js')); ?>"></script>
    <script src="<?php echo e(mix('js/frontend.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/particles.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>
   
    <?php echo \Livewire\Livewire::scripts(); ?>

    <?php echo $__env->yieldPushContent('after-scripts'); ?>
    <?php echo jquery(); ?>
    <?php echo toastr_js(); ?>
    <?php echo app('toastr')->render(); ?>
</body>
</html>
<?php /**PATH /Users/macbook-air/Desktop/kerja/Jagarta/Jagarta_web 2/resources/views/frontend/layouts/app.blade.php ENDPATH**/ ?>